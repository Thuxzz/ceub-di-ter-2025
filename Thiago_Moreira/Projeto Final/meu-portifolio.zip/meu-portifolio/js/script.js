document.addEventListener('DOMContentLoaded', function () {
    console.log('Site carregado com sucesso!');
});